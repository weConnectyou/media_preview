﻿$alert_type = { error: "error", warning: "warning", information: "information", success: "success" };
$layout = { top: "top", center: "center", bottom: "bottom", topLeft: "topLeft", topRight: "topRight", topCenter: "topCenter", bottomLeft: "bottomLeft", bottomRight: "bottomRight", inline: "inline" };

var mmsm_alert = function(alert_type, layout, text) {
    noty({ animateOpen: { opacity: 'show' }, animateClose: { opacity: 'hide' }, layout: layout, text: text, type: alert_type });

};