//ajax 请求.参数;requestParam表示参数,request_url表示请求地址,isAsync表示是否异步,callback表示执行成功的回调方法
        function AjaxRequest(request_url, requestParam, isAsync, callback) {
            $.ajax({
                type: "POST",
                url: request_url,
                async: isAsync,
                data: requestParam,
                dataType: "json",
                success: callback,
                error: function () {
                    alert("An error occurred while requesting data");
                }
            });
        }

        function bindSelectOption(dataSource, node, key, val, firstOption) {
            var currentNode = $(node);
            if (currentNode.length>0) {
                currentNode.empty();
                if (firstOption) {
                    currentNode.append('<option value="' + firstOption.val + '">' + firstOption.text + '</option>');
                }
                $.each(dataSource, function (index, item) {
                    currentNode.append('<option value="' + item[key] + '">' + item[val] + '</option>');
                });
            }
        }

        //使用模板绑定数据
        function BindData(dataSource, tpmlId, ToId) {
            $("#" + ToId).empty();
            if (dataSource) {
                $("#" + tpmlId).tmpl(dataSource).appendTo("#" + ToId);
            }
        }
        
        //取消默认事件
        function cancelElDefault(event) {
            var e = event || window.event;
            if (e && e.preventDefault) {
                e.preventDefault();
            } else {
                e.returnValue = false;
            }
        }

        // for cookie
        
        function getCookie(name) {
            var tmpStr = document.cookie;
            var tmpArr = tmpStr.split(";");
            for (var i = 0; i < tmpArr.length; i++) {
                var arr = tmpArr[i].split("=");
                if (!arr[1]) {
                    return "";
                } else if ($.trim(arr[0]) == name) {
                    return arr[1];
                }
            }
            return "";
        }

        function delCookie(name) {
            var exp = new Date();
            exp.setTime(exp.getTime() - 1);
            var cVal = this.getCookie(name);
            if (cVal != null) {
                document.cookie = name + "=" + cVal + ";expires=" + exp.toGMTString();
            }

        }
        // end for cookie
