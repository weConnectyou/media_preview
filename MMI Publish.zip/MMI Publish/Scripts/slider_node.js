﻿function InitAllSlider() {
    InitSlider($("#slider0"), $("#answer0"), 4);
    InitSlider($("#slider1"), $("#answer1"), 4);
    InitSlider($("#slider2"), $("#answer2"), 4);
    InitSlider($("#slider3"), $("#answer3"), 4);
    InitSlider($("#slider4"), $("#answer4"), 4);
    InitSlider($("#slider5"), $("#answer5"), 4);
    InitSlider($("#slider6"), $("#answer6"), 4);
}

function InitSlider(sliderNode, AnswerNode, val) {
    var sNode = $(sliderNode);
    var aNode = $(AnswerNode);
    sNode.slider({
        value: val,
        min: 0,
        max: 7,
        step: 1,
        orientation: "horizontal",
        range: "min",
        slide: function (event, ui) {
            aNode.val(ui.value);
        }
    });
    aNode.val("" + sNode.slider("value"));
}
