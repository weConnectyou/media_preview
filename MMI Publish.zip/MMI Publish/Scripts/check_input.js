﻿function checkEmpty(node) {
    var curNode = $(node);
    var parentNode = curNode.parents(".control-group");
    parentNode.removeClass("error success");
    var msgNode = parentNode.find(".help-inline");
    var val = curNode.val();
    val = $.trim(val);
    var errorMsg = curNode.attr("data-errormsg");
    if (val == "" || val.toString().length <= 0) {
        parentNode.addClass("error");
        msgNode.text(errorMsg);
        return false;
    }
    else {
        parentNode.addClass("success");
        msgNode.text("");
    }

    return true;
}

function checkSelected(node) {
    var curNode = $(node);
    var parentNode = curNode.parents(".control-group");
    parentNode.removeClass("error success");
    var msgNode = parentNode.find(".help-inline");
    var val = curNode.val();
    val = $.trim(val);
    var errorMsg = curNode.attr("data-errormsg");
    if (val == 0 || val == "0") {
        parentNode.addClass("error");
        msgNode.text(errorMsg);
        return false;
    }
    else {
        parentNode.addClass("success");
        msgNode.text("");
    }

    return true;
}

function checkLenght(node, lenght, limit) {
    if (checkEmpty(node)) {
        var curNode = $(node);
        var parentNode = curNode.parents(".control-group");
        parentNode.removeClass("error success");
        var msgNode = parentNode.find(".help-inline");
        var val = curNode.val();
        val = $.trim(val);
        if (val.length < lenght) {
            parentNode.addClass("error");
            msgNode.text("* the input is asked for at least " + lenght + " chars.");
            return false;
        }
        else if (val.length > limit) {
            parentNode.addClass("error");
            msgNode.text("* the input is limited int " + limit + " chars.");
            return false;
        }
        else {
            parentNode.addClass("success");
            msgNode.text("");
            return true;
        }
    }
    else {
        return false;
    }
}

function checkEmail(node) {
    if (checkEmpty(node)) {
        var curNode = $(node);
        var parentNode = curNode.parents(".control-group");
        parentNode.removeClass("error success");
        var msgNode = parentNode.find(".help-inline");
        var emial = $.trim(curNode.val());
        if (emial.length > 80) {
            parentNode.addClass("error");
            msgNode.text("* the input is limited in 80 chars.");
            return false;
        }
        emial = emial.toLowerCase();
        var checkeEmail = /^([a-z0-9_]|\-|\.)+@(([a-z0-9_]|\-)+\.)+[a-z]{2,4}$/;

        if (!checkeEmail.exec(emial)) {
            parentNode.addClass("error");
            msgNode.text("* please input a valid email.");
            return false;
        }
        parentNode.addClass("success");
        msgNode.text("");
        return true;
    }
    else {
        return false;
    }
};

function clearNode(node) {
    var curNode = $(node);
    curNode.val("");
    var parentNode = curNode.parents(".control-group");
    parentNode.removeClass("error success");
    var msgNode = parentNode.find(".help-inline");
    msgNode.text("");
}

